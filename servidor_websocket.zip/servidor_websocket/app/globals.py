clientes_conectados = {}
historial_clientes = {}
grupos = {}
clientes_conectados_por_nombre = {}
CLAVE_CORRECTA_HASH = "513077c52f7025d6d370560150a3c967bee0a9635ac3624a3ee65ef494e16e64"  # SHA-256 real
